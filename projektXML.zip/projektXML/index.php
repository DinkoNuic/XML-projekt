<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FC Barcelona</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #0033A0;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        nav {
            background-color: #eee;
            padding: 10px 0;
            text-align: center;
        }
        nav a {
            text-decoration: none;
            color: #333;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        nav a:hover {
            background-color: #ddd;
        }
        section {
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #0033A0;
        }
        img {
            display: block;
            margin: 0 auto 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>FC Barcelona</h1>
    </header>
    <nav>
        <a href="trofeji.php">Trofeji</a>
        <a href="legende.php">Legende</a>
        <a href="ekipa.php">Ekipa</a>
    </nav>
    <section>
        <h2>O klubu</h2>
        <img src="grb_barcelone.jpg" alt="Grb FC Barcelone" width="200px">
        <p>Futbol Club Barcelona (također poznat i pod nazivom Barcelona ili jednostavnije Barça) je profesionalni nogometni klub smješten u Barceloni (Katalonija).<br>

        FC Barcelonu je 1899. godine osnovala skupina švicarskih, engleskih i katalonskih <br>
        nogometaša koju je predvodio Joan Gamper, a klub je postao simbol katalonske kulture <br>
        i katalonizma uz moto "Više od kluba". Službena himna Barcelone je Cant del Barça <br>
        autora Jaumea Picasa i Josepa Marije Espinàsa. To je drugi najbogatiji nogometni klub u svijetu s prosječnom zaradom od 398 milijuna Eura. <br>
        Najveći nogometni rival Barcelone je Real Madrid, a njihove zajedničke utakmice poznate su pod nazivom El Clásico.</p>
    </section>
</body>
</html>
