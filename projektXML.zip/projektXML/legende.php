<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legende FC Barcelone</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #0033A0;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        nav {
            background-color: #eee;
            padding: 10px 0;
            text-align: center;
        }
        nav a {
            text-decoration: none;
            color: #333;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        nav a:hover {
            background-color: #ddd;}
        section {
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #0033A0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <header>
        <h1>FC Barcelona</h1>
    </header>
    <nav>
        <a href="index.php">Home</a>
        <a href="trofeji.php">Trofeji</a>
        <a href="ekipa.php">Ekipa</a>
    </nav>
    <section>
        <h2>Legende FC Barcelone</h2>
        <table>
            <tr>
                <th>Ime</th>
                <th>Pozicija</th>
                <th>Godine</th>
            </tr>
            <tr>
                <td>Johan Cruyff</td>
                <td>Napadač / Trener</td>
                <td>1973-1978 / 1988-1996</td>
            </tr>
            <tr>
                <td>Lionel Messi</td>
                <td>Napadač</td>
                <td>2000-2021</td>
            </tr>
            <tr>
                <td>Xavi Hernandez</td>
                <td>Vezni</td>
                <td>1998-2015</td>
            </tr>
            <tr>
                <td>Andres Iniesta</td>
                <td>Vezni</td>
                <td>2002-2018</td>
            </tr>
            <tr>
                <td>Carles Puyol</td>
                <td>Branič</td>
                <td>1999-2014</td>
            </tr>
        
        </table>
    </section>
</body>
</html>
